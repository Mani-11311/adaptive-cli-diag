# Adaptive CLI Diagnostics

A real-time system health monitor for the terminal. Collects CPU, memory, disk, network, temperature, and process metrics and displays them in a colour-coded dashboard that adapts to configurable warn/critical thresholds.

---

## Features

- **`diagnose`** — full snapshot of all system metrics, with `--watch` for live refresh
- **`top`** — process table sorted by CPU or memory, with live mode
- **`config`** — view and update thresholds; changes persist across runs
- **`report`** — export a JSON snapshot for logging or CI pipelines
- **`ping-check`** — concurrent ICMP reachability check for any number of hosts

Metrics are collected in parallel so a full snapshot takes ~0.4 s regardless of how many subsystems are checked.

---

## Requirements

- Python 3.10+
- Windows, macOS, or Linux

---

## Installation

```bash
pip install -r requirements.txt
```

---

## Usage

```bash
# One-shot diagnostics snapshot
python main.py diagnose

# Live refresh every 2 s (Ctrl+C to quit)
python main.py diagnose --watch

# Live refresh with a custom interval
python main.py diagnose --watch --interval 5

# Show top 10 processes sorted by memory
python main.py top --count 10 --sort mem

# Live process view
python main.py top --watch

# View current thresholds
python main.py config

# Lower memory warning threshold to 70 %
python main.py config --mem-warn 70

# Reset all thresholds to defaults
python main.py config --reset

# Export JSON report
python main.py report report.json

# Check host reachability (all pinged in parallel)
python main.py ping-check google.com github.com 8.8.8.8

# Show version
python main.py --version
```

---

## Configuration

Thresholds are saved to `~/.config/adaptive-cli-diag/config.json` and merged with defaults on every run, so partial configs are always safe.

| Setting | Default | Description |
|---|---|---|
| `cpu_warn` | 70 | CPU warning threshold (%) |
| `cpu_crit` | 90 | CPU critical threshold (%) |
| `mem_warn` | 75 | Memory warning threshold (%) |
| `mem_crit` | 90 | Memory critical threshold (%) |
| `disk_warn` | 80 | Disk warning threshold (%) |
| `disk_crit` | 95 | Disk critical threshold (%) |
| `temp_warn` | 75 | Temperature warning threshold (°C) |
| `temp_crit` | 90 | Temperature critical threshold (°C) |
| `interval` | 2 | Live-refresh interval in seconds |
| `top_procs` | 5 | Number of processes shown in the diagnose snapshot |

---

## Severity Colours

| Indicator | Meaning |
|---|---|
| Green `[OK]` | Metric is within normal range |
| Yellow `[!!]` | Metric has crossed the warning threshold |
| Red `[XX]` | Metric has crossed the critical threshold |
